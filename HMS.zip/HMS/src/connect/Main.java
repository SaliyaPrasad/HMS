package connect;


public class Main {

   
    public static void main(String[] args) {
       MySqlConnect connect = new MySqlConnect();
      connect.getData();
    }
    
}
