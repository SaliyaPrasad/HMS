/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import connect.MySqlConnect;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Saliya Prasad
 */
public class Stool_test extends javax.swing.JFrame {

     Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    public Stool_test() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Adobe Hebrew", 0, 48)); // NOI18N
        jLabel1.setText("Stool Test");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(180, 30, 290, 50);

        jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel4.setText("Blood Group");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(90, 200, 110, 21);

        jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel5.setText("Consistency");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(90, 240, 98, 21);

        jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel6.setText("Mucus");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(90, 280, 52, 21);

        jLabel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel7.setText("Colour/ Appcarance");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(90, 320, 159, 21);

        jLabel8.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel8.setText("Chemical Relation");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(90, 360, 145, 21);

        jLabel9.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel9.setText("Reaction");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(90, 400, 71, 21);

        jLabel10.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel10.setText("Puscells");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(90, 440, 67, 21);

        jLabel11.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel11.setText("RBS'S");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(90, 480, 53, 21);

        jLabel12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel12.setText("OVA");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(90, 520, 38, 21);

        jLabel13.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel13.setText("Bacteria");
        jPanel1.add(jLabel13);
        jLabel13.setBounds(90, 560, 66, 21);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField1);
        jTextField1.setBounds(270, 200, 200, 20);
        jPanel1.add(jTextField2);
        jTextField2.setBounds(270, 240, 200, 22);
        jPanel1.add(jTextField3);
        jTextField3.setBounds(270, 280, 200, 22);
        jPanel1.add(jTextField4);
        jTextField4.setBounds(270, 320, 200, 22);
        jPanel1.add(jTextField5);
        jTextField5.setBounds(270, 360, 200, 22);
        jPanel1.add(jTextField6);
        jTextField6.setBounds(270, 400, 200, 22);
        jPanel1.add(jTextField7);
        jTextField7.setBounds(270, 440, 200, 22);
        jPanel1.add(jTextField8);
        jTextField8.setBounds(270, 480, 200, 22);
        jPanel1.add(jTextField9);
        jTextField9.setBounds(270, 520, 200, 22);
        jPanel1.add(jTextField10);
        jTextField10.setBounds(270, 560, 200, 22);

        jButton1.setText("Insert");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(350, 610, 100, 30);

        jLabel14.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel14.setText("Patient Id");
        jPanel1.add(jLabel14);
        jLabel14.setBounds(90, 150, 80, 30);
        jPanel1.add(jTextField11);
        jTextField11.setBounds(270, 160, 200, 22);
        jPanel1.add(jTextField12);
        jTextField12.setBounds(270, 120, 200, 22);

        jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel3.setText("Stool Test Id");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(90, 110, 130, 30);

        jButton2.setText("Get Data");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(240, 610, 90, 30);

        jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bg_pic/cq5dam.md.1200.675.jpg"))); // NOI18N
        jPanel1.add(jLabel2);
        jLabel2.setBounds(-80, -10, 1200, 670);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1120, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 660, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        
    }//GEN-LAST:event_jTextField1ActionPerformed
private void formWindowClosing(java.awt.event.WindowEvent evt) {                                   
      this.hide();
       Test_Menu frm = new Test_Menu();
       frm.setVisible(true);
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       try{
            String sql ="INSERT INTO stool_test"
                    +"(s_test_id , PatientID ,blood_group, consistency, mucus, colour, chemical_rel, reaction, puscells, rbs, ova, bacteria)"
                    +"VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
            con=MySqlConnect.ConnectDB();
            pst = con.prepareStatement(sql);
            pst.setString(1,jTextField12.getText());
            pst.setString(2,jTextField11.getText());
            pst.setString(3,jTextField1.getText());
            pst.setString(4,jTextField2.getText());
            pst.setString(5,jTextField3.getText());
            pst.setString(6,jTextField4.getText());
            pst.setString(7,jTextField5.getText());
            pst.setString(8,jTextField6.getText());
            pst.setString(9,jTextField7.getText());
            pst.setString(10,jTextField8.getText());
            pst.setString(11,jTextField9.getText());
            pst.setString(12,jTextField10.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "inserted successfully");
            
            
        }catch(SQLException | HeadlessException e){
            JOptionPane.showMessageDialog(null, e);
    }    
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Stool_testRecord frm = new Stool_testRecord();
        frm.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Stool_test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Stool_test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Stool_test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Stool_test.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Stool_test().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
